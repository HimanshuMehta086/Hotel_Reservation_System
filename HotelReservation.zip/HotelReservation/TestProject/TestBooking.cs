﻿namespace TestProject
{
    public class TestBooking
    {
        public (int, int) Booking { get; set; }
        public string ExpectedValue { get; set; }
    }
}
