using HotelReservation;
using System.Collections.Generic;
using Xunit;

namespace TestProject
{
    /// <summary>
    /// Test cases
    /// </summary>
    public class HotelReservationTest
    {
        /// <summary>
        /// Requests outside our planning period are declined (Size=1)
        /// </summary>
        [Fact]
        public void AllDeclined()
        {
            var testBookings = new TestHotel();
            testBookings.Size = 1;
            testBookings.Bookings.Add(new TestBooking()
            {
                ExpectedValue = StatusConstants.Decline,
                Booking = (-4, 2)
            });
            testBookings.Bookings.Add(new TestBooking()
            {
                ExpectedValue = StatusConstants.Decline,
                Booking = (200, 400)
            });
           
            var bookingList = new List<(int, int)>();

            foreach (var testBooking in testBookings.Bookings)
            {
                bookingList.Add(testBooking.Booking);
            }
            var response = Program.GetFinalResult(bookingList.ToArray(), testBookings.Size);
            for (int i = 0; i < response.BookingsResponse.Count; i++)
            {
                Assert.Equal(testBookings.Bookings[i].ExpectedValue, response.BookingsResponse[i].Result);
            }
        }

        /// <summary>
        /// Requests are accepted (Size=3)
        /// </summary>
        [Fact]
        public void AllAccepted()
        {
            var testBookings = new TestHotel();
            testBookings.Size = 3;
            testBookings.Bookings.Add(new TestBooking()
            {
                ExpectedValue = StatusConstants.Accept,
                Booking = (0, 5)
            });
            testBookings.Bookings.Add(new TestBooking()
            {
                ExpectedValue = StatusConstants.Accept,
                Booking = (7, 13)
            });
            testBookings.Bookings.Add(new TestBooking()
            {
                ExpectedValue = StatusConstants.Accept,
                Booking = (3, 9)
            });
            testBookings.Bookings.Add(new TestBooking()
            {
                ExpectedValue = StatusConstants.Accept,
                Booking = (5, 7)
            });
            testBookings.Bookings.Add(new TestBooking()
            {
                ExpectedValue = StatusConstants.Accept,
                Booking = (6, 6)
            });
            testBookings.Bookings.Add(new TestBooking()
            {
                ExpectedValue = StatusConstants.Accept,
                Booking = (0, 4)
            });

            var bookingList = new List<(int, int)>();

            foreach (var testBooking in testBookings.Bookings)
            {
                bookingList.Add(testBooking.Booking);
            }
            var response = Program.GetFinalResult(bookingList.ToArray(), testBookings.Size);
            for (int i = 0; i < response.BookingsResponse.Count; i++)
            {
                Assert.Equal(testBookings.Bookings[i].ExpectedValue, response.BookingsResponse[i].Result);
            }
        }

        /// <summary>
        /// Requests are declined (Size=3)
        /// </summary>
        [Fact]
        public void DeclineAfterAccept()
        {
            var testBookings = new TestHotel();
            testBookings.Size = 3;
            testBookings.Bookings.Add(new TestBooking()
            {
                ExpectedValue = StatusConstants.Accept,
                Booking = (1, 3)
            });
            testBookings.Bookings.Add(new TestBooking()
            {
                ExpectedValue = StatusConstants.Accept,
                Booking = (2, 5)
            });
            testBookings.Bookings.Add(new TestBooking()
            {
                ExpectedValue = StatusConstants.Accept,
                Booking = (1, 9)
            });
            testBookings.Bookings.Add(new TestBooking()
            {
                ExpectedValue = StatusConstants.Decline,
                Booking = (0, 15)
            });

            var bookingList = new List<(int, int)>();

            foreach (var testBooking in testBookings.Bookings)
            {
                bookingList.Add(testBooking.Booking);
            }
            var response = Program.GetFinalResult(bookingList.ToArray(), testBookings.Size);
            for (int i = 0; i < response.BookingsResponse.Count; i++)
            {
                Assert.Equal(testBookings.Bookings[i].ExpectedValue, response.BookingsResponse[i].Result);
            }
        }

        /// <summary>
        /// Requests can be accepted after a decline (Size=3)
        /// </summary>
        [Fact]
        public void AcceptAfterDecline()
        {
            var testBookings = new TestHotel();
            testBookings.Size = 3;
            testBookings.Bookings.Add(new TestBooking()
            {
                ExpectedValue = StatusConstants.Accept,
                Booking = (1, 3)
            });
            testBookings.Bookings.Add(new TestBooking()
            {
                ExpectedValue = StatusConstants.Accept,
                Booking = (0, 15)
            });
            testBookings.Bookings.Add(new TestBooking()
            {
                ExpectedValue = StatusConstants.Accept,
                Booking = (1, 9)
            });
            testBookings.Bookings.Add(new TestBooking()
            {
                ExpectedValue = StatusConstants.Decline,
                Booking = (2, 5)
            });
            testBookings.Bookings.Add(new TestBooking()
            {
                ExpectedValue = StatusConstants.Accept,
                Booking = (4, 9)
            });

            var bookingList = new List<(int, int)>();

            foreach (var testBooking in testBookings.Bookings)
            {
                bookingList.Add(testBooking.Booking);
            }
            var response = Program.GetFinalResult(bookingList.ToArray(), testBookings.Size);
            for (int i = 0; i < response.BookingsResponse.Count; i++)
            {
                Assert.Equal(testBookings.Bookings[i].ExpectedValue, response.BookingsResponse[i].Result);
            }
        }

        /// <summary>
        /// Complex Requests (Size=2)
        /// </summary>
        [Fact]
        public void ComplexRequests()
        {
            var testBookings = new TestHotel();
            testBookings.Size = 2;
            testBookings.Bookings.Add(new TestBooking()
            {
                ExpectedValue = StatusConstants.Accept,
                Booking = (1, 3)
            });
            testBookings.Bookings.Add(new TestBooking()
            {
                ExpectedValue = StatusConstants.Accept,
                Booking = (0, 4)
            });
            testBookings.Bookings.Add(new TestBooking()
            {
                ExpectedValue = StatusConstants.Decline,
                Booking = (2, 3)
            });
            testBookings.Bookings.Add(new TestBooking()
            {
                ExpectedValue = StatusConstants.Accept,
                Booking = (5, 5)
            });
            testBookings.Bookings.Add(new TestBooking()
            {
                ExpectedValue = StatusConstants.Accept,
                Booking = (4, 10)
            });
            testBookings.Bookings.Add(new TestBooking()
            {
                ExpectedValue = StatusConstants.Accept,
                Booking = (10, 10)
            });
            testBookings.Bookings.Add(new TestBooking()
            {
                ExpectedValue = StatusConstants.Accept,
                Booking = (6, 7)
            });
            testBookings.Bookings.Add(new TestBooking()
            {
                ExpectedValue = StatusConstants.Decline,
                Booking = (8, 10)
            });
            testBookings.Bookings.Add(new TestBooking()
            {
                ExpectedValue = StatusConstants.Accept,
                Booking = (8, 9)
            });
            var bookingList = new List<(int, int)>();

            foreach (var testBooking in testBookings.Bookings)
            {
                bookingList.Add(testBooking.Booking);
            }
            var response = Program.GetFinalResult(bookingList.ToArray(), testBookings.Size);
            for (int i = 0; i < response.BookingsResponse.Count; i++)
            {
                Assert.Equal(testBookings.Bookings[i].ExpectedValue, response.BookingsResponse[i].Result);
            }
        }
    }
}
