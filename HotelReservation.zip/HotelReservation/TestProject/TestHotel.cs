﻿using System.Collections.Generic;

namespace TestProject
{
    public class TestHotel
    {
        public TestHotel()
        {
            Bookings = new List<TestBooking>();
        }
        public int Size { get; set; }
        public List<TestBooking> Bookings { get; set; }
    }
}
