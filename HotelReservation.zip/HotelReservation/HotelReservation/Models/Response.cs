﻿using System.Collections.Generic;

namespace HotelReservation.Models
{
    public class Response
    {
        public Response()
        {
            BookingsResponse = new List<BookingResponse>();
        }
        public List<BookingResponse> BookingsResponse { get; set; }
    }
}
