﻿namespace HotelReservation.Models
{
    public class BookingResponse
    {
        public string BookingNumber { get; set; }
        public int StartDate { get; set; }
        public int EndDate { get; set; }
        public string Result { get; set; }
    }
}
