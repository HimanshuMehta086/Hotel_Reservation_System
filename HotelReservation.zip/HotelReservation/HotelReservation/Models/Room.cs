﻿using System.Collections.Generic;

namespace HotelReservation.Models
{
    public class Room
    {
        public Room()
        {
            Days = new Dictionary<string, bool>();
        }
        public string RoomNumber { get; set; }
        public Dictionary<string, bool> Days { get; set; }
    }
}
