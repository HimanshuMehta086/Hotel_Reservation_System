﻿using System.Collections.Generic;

namespace HotelReservation.Models
{
    public class Hotel
    {
        public Hotel()
        {
            Rooms = new List<Room>();
        }
        public List<Room> Rooms { get; set; }
    }
}
