﻿namespace HotelReservation
{
    public static class StatusConstants
    {
        public const string Accept = "Accept";
        public const string Decline = "Decline";
    }
}
