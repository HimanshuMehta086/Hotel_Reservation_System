﻿using HotelReservation.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace HotelReservation
{
    public class Program
    {
        /// <summary>
        /// Created console application for faster debugging purpose (in real time application a class library is preffered)
        /// </summary>
        static void Main()
        {
            Console.WriteLine("Enter the size of the hotel");
            var hotelSize = Console.ReadLine();
            int.TryParse(hotelSize, out int size);
            var bookings = new (int, int)[]
             {
                  (0,5),(7,13),(3,9), (5,7), (6,6), (0,4)/*, (4,10), (10,10),(6,7),(8,10),(8,9)*/
             };
            var response = GetFinalResult(bookings, size);
            foreach (var booking in response.BookingsResponse)
            {
                Console.WriteLine($"Booking Number :: {booking.BookingNumber}, Start Date :: {booking.StartDate}," +
                    $" End Date :: {booking.EndDate}, Result :: {booking.Result}");
            }
        }

        /// <summary>
        /// This method gives you the final response of all the input bookings
        /// </summary>
        /// <param name="bookings">input bookings tuple</param>
        /// <param name="size">number of rooms in the hotel</param>
        /// <returns>Final Response</returns>
        public static Response GetFinalResult((int, int)[] bookings, int size)
        {
            if (size > 1000)
                throw new ArgumentException("Hotel size can't be greater than 1000");

            var response = new Response();
            var hotel = InitializeRooms(size);  // add rooms in hotel
            for (int i = 0; i < bookings.Length; i++)  // loop through every booking
            {
                var bookingResponse = new BookingResponse();
                if (i == 0)
                {
                    bookingResponse = GetBookingResponse(bookings[i], hotel, true); //get first booking result
                }
                else
                {
                    bookingResponse = GetBookingResponse(bookings[i], hotel, false);  //get booking result
                }
                bookingResponse.BookingNumber = $"Booking {i + 1}".ToUpper();
                response.BookingsResponse.Add(bookingResponse);  // add booking response to final response
            }
            return response;
        }


        /// <summary>
        /// This method add rooms in hotel based on size
        /// </summary>
        /// <param name="size">number of rooms in the hotel</param>
        /// <returns>hotel object containing rooms</returns>
        private static Hotel InitializeRooms(int size)
        {
            var hotel = new Hotel();
            for (int i = 1; i <= size; i++)
            {
                var room = new Room();
                room.RoomNumber = $"Room {i}";
                for (int j = 0; j < 365; j++)
                {
                    room.Days.Add($"Day {j}", true);
                }
                hotel.Rooms.Add(room);
            }
            return hotel;
        }


        /// <summary>
        /// This method gives you the individual booking response
        /// </summary>
        /// <param name="booking">booking tuple</param>
        /// <param name="hotel">hotel object containing rooms</param>
        /// <returns>BookingResponse</returns>
        private static BookingResponse GetBookingResponse((int, int) booking, Hotel hotel, bool isFirstBooking)
        {
            var bookingResponse = new BookingResponse();
            bookingResponse.StartDate = booking.Item1;
            bookingResponse.EndDate = booking.Item2;
            var isAllRoomsOccupiedAtleastOnce = CheckForRoomsOccupancyAtleastOnce(hotel); // checks whether the booking is there for all the rooms atleast once
            if (bookingResponse.StartDate > 0 && !isFirstBooking && isAllRoomsOccupiedAtleastOnce)
            {
                //gets the order of rooms to be passed for efficient utilisation of hotel rooms
                var newHotel = GetOrderOfRooms(hotel, bookingResponse.StartDate);
                bookingResponse.Result = GetBookingStatus(bookingResponse.StartDate, bookingResponse.EndDate, newHotel.Rooms);
            }
            else
            {
                bookingResponse.Result = GetBookingStatus(bookingResponse.StartDate, bookingResponse.EndDate, hotel.Rooms);
            }
            return bookingResponse;
        }

        private static bool CheckForRoomsOccupancyAtleastOnce(Hotel hotel)
        {
            var roomsOccupancyCount = 0;
            foreach (var room in hotel.Rooms)
            {
                if (room.Days.Values.Any(x => x.Equals(false)))
                {
                    roomsOccupancyCount = roomsOccupancyCount + 1;
                }
            }
            if (roomsOccupancyCount == hotel.Rooms.Count)
                return true;
            else
                return false;
        }

        private static Hotel GetOrderOfRooms(Hotel hotel, int startDate)
        {
            var newHotel = new Hotel();
            var dic = new Dictionary<string, int>();

            // gets the distance of a given booking from all the rooms to find the most efficient room
            foreach (var room in hotel.Rooms)
            {
                for (int i = (startDate - 1); i >= 0; i--)
                {
                    if (!room.Days[$"Day {i}"])
                    {
                        dic.Add(room.RoomNumber, startDate - i);
                        break;
                    }
                }
            }
            var list = dic.OrderBy(x => x.Value);
            dic = list.ToDictionary(x => x.Key, x => x.Value);
            foreach (var item in dic)
            {
                foreach (var room in hotel.Rooms)
                {
                    if (item.Key == room.RoomNumber)
                    {
                        newHotel.Rooms.Add(room);
                    }
                }
            }
            // returns a new hotel object with efficient list of rooms
            return newHotel;
        }

        /// <summary>
        /// This method provides you the status of a particular booking 
        /// </summary>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <param name="rooms"></param>
        /// <returns>Accept/Decline</returns>
        private static string GetBookingStatus(int startDate, int endDate, IEnumerable<Room> rooms)
        {
            if (startDate < 0 || endDate > 364) // if start date is less than zero or end date is greater than 364 then simply Decline
            {
                return StatusConstants.Decline;
            }
            else if (endDate < startDate)
            {
                return StatusConstants.Decline; // if end date is less than start date then simply Decline
            }
            else
            {
                foreach (var room in rooms)
                {
                    var isAvailable = CheckRoomAvailability(room, startDate, endDate);
                    if (isAvailable)
                    {
                        for (int i = startDate; i <= endDate; i++)
                        {
                            room.Days[$"Day {i}"] = false;
                        }

                        return StatusConstants.Accept;
                    }
                }
                return StatusConstants.Decline;
            }
        }


        /// <summary>
        /// This method checks the availability in a given room based on start and end date
        /// </summary>
        /// <param name="room"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <returns>true/false</returns>
        private static bool CheckRoomAvailability(Room room, int startDate, int endDate)
        {
            var durationCount = -1;
            // if either room is not vacant for start or end date then simply return false
            if (!room.Days[$"Day {startDate}"] || !room.Days[$"Day {endDate}"])
            {
                return false;
            }
            for (int i = startDate; i <= endDate; i++)
            {
                if (!room.Days[$"Day {i}"])
                {
                    return false;
                }
                else
                {
                    durationCount = durationCount + 1;
                }
            }
            if (durationCount == (endDate - startDate))
            {
                return true;
            }
            return false;
        }
    }
}
